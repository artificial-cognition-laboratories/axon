// @bun
// node_modules/hookable/dist/index.mjs
function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
var defaultTask = { run: (function_) => function_() };
var _createTask = () => defaultTask;
var createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce((promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))), Promise.resolve());
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = undefined;
    this._after = undefined;
    this._deprecatedMessages = undefined;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {};
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set;
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {}
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = undefined;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = undefined;
      _function = undefined;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map((key) => this.hook(key, hooks[key]));
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : undefined;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(name in this._hooks ? [...this._hooks[name]] : [], arguments_);
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== undefined) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== undefined) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}

// node_modules/@arcforge/cognet/src/host.ts
import { AsyncLocalStorage as AsyncLocalStorage2 } from "async_hooks";

// node_modules/@arcforge/err/src/map.ts
var errorMap = {
  UNKNOWN: {
    code: "AX-UNKNOWN-001",
    title: "Unclassified Error",
    description: "An error occurred that hasn't been given a proper code yet. This is itself worth fixing \u2014 see the err(cause) call site that produced it.",
    source: "runtime",
    severity: "fatal"
  },
  PROMPT_NOT_FOUND: {
    code: "AX-PROMPT-001",
    title: "Prompt Not Found",
    description: "The requested prompt was not found in the agent's blueprint. It may not be declared, or the agent needs to be re-prepared.",
    source: "runtime",
    severity: "fatal"
  },
  PROMPT_FILE_NOT_FOUND: {
    code: "AX-PROMPT-002",
    title: "Prompt File Missing",
    description: "The prompt is declared but its source file no longer exists on disk.",
    source: "runtime",
    severity: "fatal"
  },
  PROMPT_RENDER_FAILED: {
    code: "AX-PROMPT-003",
    title: "Prompt Render Failed",
    description: "The prompt's source file failed to compile or render \u2014 likely a malformed SFC (content outside <template>/<script>/<style>) or an error thrown while rendering. See the cause for the underlying parser/render error.",
    source: "runtime",
    severity: "fatal"
  },
  SCRIPT_NOT_FOUND: {
    code: "AX-SCRIPT-001",
    title: "Script Not Found",
    description: "The requested script was not found in the agent's blueprint. It may not be declared, or the agent needs to be re-prepared.",
    source: "runtime",
    severity: "fatal"
  },
  SCRIPT_FILE_NOT_FOUND: {
    code: "AX-SCRIPT-002",
    title: "Script File Missing",
    description: "The script is declared but its source file no longer exists on disk.",
    source: "runtime",
    severity: "fatal"
  },
  ENGINE_MISSING: {
    code: "AX-ENGINE-001",
    title: "No Engine Configured",
    description: "The agent's blueprint has no engine \u2014 it cannot dispatch to a model. Set `engine` in axon.config.ts.",
    source: "runtime",
    severity: "fatal"
  },
  INJECT_OUTSIDE_RUNTIME: {
    code: "AX-RUNTIME-001",
    title: "Runtime Accessed Before Boot",
    description: "A runtime global (axon, args) was read before the runtime finished booting.",
    source: "runtime",
    severity: "fatal"
  },
  BOOT_FAILED: {
    code: "AX-BOOT-001",
    title: "Agent Failed To Start",
    description: "The agent's runtime crashed while starting, before it could accept requests.",
    source: "runtime",
    severity: "fatal"
  },
  BOOT_SCRIPT_FAILED: {
    code: "AX-BOOT-002",
    title: "Boot Script Failed",
    description: "The agent's boot.vue threw while rendering \u2014 check the script setup block for the error.",
    source: "runtime",
    severity: "fatal"
  },
  BOOT_SCRIPT_INVALID: {
    code: "AX-BOOT-003",
    title: "Boot Script Malformed",
    description: "The agent's boot.vue has content outside its recognized <script>/<template> blocks, or otherwise failed to parse as a valid SFC.",
    source: "runtime",
    severity: "fatal"
  },
  COGNET_ACCESSED_BEFORE_LOAD: {
    code: "AX-COGNET-001",
    title: "Cognet Accessed Before Load",
    description: "A cognet global (kernel, phase, system, blueprint) was read before the brain finished loading, or outside the loop body that owns it.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_LOOP_ALREADY_DECLARED: {
    code: "AX-COGNET-002",
    title: "Loop Already Declared",
    description: "A cognet's main() called loop() more than once \u2014 the loop is the program's entire main body and can only be declared once.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_ALREADY_LOADED: {
    code: "AX-COGNET-003",
    title: "Cognet Bound To A Different Kernel",
    description: "This cognet instance already loaded against a different kernel ABI \u2014 a reload produced a conflicting bind instead of a clean swap.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_NO_LOOP: {
    code: "AX-COGNET-004",
    title: "Cognet Declared No Loop",
    description: "The cognet's main() ran (or was woken) without ever declaring loop() \u2014 there is no program to run.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_MAX_TICKS: {
    code: "AX-COGNET-005",
    title: "Cognet Exceeded Max Ticks",
    description: "The cognet's loop ran more ticks in one wake than its configured limit allows \u2014 likely a runaway loop that never calls stop().",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_ABI_MISMATCH: {
    code: "AX-COGNET-006",
    title: "Cognet ABI Mismatch",
    description: "The compiled cognet targets a kernel ABI version the running kernel doesn't provide \u2014 rebuild the cognet against the current framework version.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_MISSING: {
    code: "AX-COGNET-007",
    title: "No Compiled Cognet",
    description: "The blueprint points at a compiled cognet bundle that doesn't exist on disk yet \u2014 run `axon prepare` before booting.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_HASH_MISMATCH: {
    code: "AX-COGNET-008",
    title: "Cognet Bundle Hash Mismatch",
    description: "The compiled cognet bundle on disk doesn't match the hash the blueprint expects \u2014 it's stale or was tampered with. Run `axon prepare` again.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_INVALID: {
    code: "AX-COGNET-009",
    title: "Invalid Cognet Bundle",
    description: "The compiled cognet's default export isn't a real cognet definition \u2014 the compile step produced something malformed.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_IDENTITY_MISMATCH: {
    code: "AX-COGNET-010",
    title: "Cognet Identity Mismatch",
    description: "The compiled cognet artifact's own name doesn't match what the blueprint declared \u2014 the wrong bundle may be at this path.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_CONFIG_MISSING: {
    code: "AX-COGNET-011",
    title: "Cognet Config Missing",
    description: "No cognet.config.ts was found in the cognet's source directory \u2014 every cognet needs one to declare its identity.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_BUILD_FAILED: {
    code: "AX-COGNET-012",
    title: "Cognet Failed To Compile",
    description: "Bundling the cognet's source into a runnable artifact failed \u2014 check the build log for the underlying syntax or import error.",
    source: "cognet",
    severity: "fatal"
  },
  COGNET_NOT_FOUND: {
    code: "AX-COGNET-013",
    title: "Cognet Not Found",
    description: "The cognet named by `cognet:` in axon.config.ts could not be located. The detail says where it was looked for \u2014 a registry that answered 404, or a node_modules tree it was missing from. Check the specifier for a typo, and check which registry the CLI is pointed at (AXON_API_BASE).",
    source: "cognet",
    severity: "fatal"
  },
  MODULE_SPECIFIER_INVALID: {
    code: "AX-PROJECT-005",
    title: "Invalid Module Specifier",
    description: "Module names must be scoped as @scope/name. The registry does not accept unscoped packages, so an unscoped specifier can never resolve.",
    source: "manifest",
    severity: "fatal"
  },
  CONFIG_MODULES_UNPARSEABLE: {
    code: "AX-PROJECT-006",
    title: "Could Not Edit axon.config.ts",
    description: "The install succeeded but the module entry could not be written into the config's modules array automatically \u2014 add or remove it by hand.",
    source: "manifest",
    severity: "fatal"
  },
  MODULE_DEPENDENCY_INSTALL_FAILED: {
    code: "AX-PROJECT-004",
    title: "Module Dependencies Failed To Install",
    description: "The module source was downloaded, but its npm dependencies could not be materialized for the agent. Resolve the package-manager error and run the install again.",
    source: "manifest",
    severity: "fatal"
  },
  BLUEPRINT_NOT_LOADED: {
    code: "AX-PROJECT-002",
    title: "Blueprint Accessed Before Load",
    description: "Something read the blueprint's current value before load() had ever run.",
    source: "manifest",
    severity: "fatal"
  },
  AGENT_INVALID: {
    code: "AX-PROJECT-003",
    title: "Invalid Agent Directory",
    description: "The agent root has no package.json \u2014 every agent is a real package, this one isn't.",
    source: "manifest",
    severity: "fatal"
  },
  CORRUPT_JSON: {
    code: "AX-PROJECT-016",
    title: "Corrupt JSON File",
    description: "A stored JSON file failed to parse \u2014 it may have been hand-edited into an invalid state, or a write was interrupted mid-flight.",
    source: "manifest",
    severity: "fatal"
  },
  FILE_UNREADABLE: {
    code: "AX-PROJECT-032",
    title: "File Could Not Be Read",
    description: "A file exists but could not be read \u2014 most often a permissions problem, a directory where a file was expected, or a disk error. Distinct from a missing file, which is an ordinary absent-surface state.",
    source: "manifest",
    severity: "fatal"
  },
  PROVIDER_NOT_CONNECTED: {
    code: "AX-TUI-011",
    title: "Provider Not Connected",
    description: "The selected model routes through a provider (OpenRouter, Codex) that isn't connected yet \u2014 connect it before picking a model on that route.",
    source: "tui",
    severity: "fatal"
  },
  PALETTE_INPUT_REQUIRED: {
    code: "AX-TUI-012",
    title: "Required Input Missing",
    description: "A palette command needs a value for this field before it can run.",
    source: "tui",
    severity: "fatal"
  },
  BENCH_NO_CASES: {
    code: "AX-TUI-013",
    title: "Bench Declared No Cases",
    description: "The bench's test file ran to completion under Bun but never declared a single benchmark case.",
    source: "tui",
    severity: "fatal"
  },
  PROJECT_NOT_FOUND: {
    code: "AX-PROJECT-017",
    title: "Project Not Found",
    description: "No axon.config.ts, module.config.ts, cognet.config.ts, bench.config.ts, or prompt.config.ts was found at this path \u2014 it isn't a recognized project directory.",
    source: "manifest",
    severity: "fatal"
  },
  PROJECT_WRONG_KIND: {
    code: "AX-PROJECT-011",
    title: "Wrong Project Kind",
    description: "This command targets one project kind, and the directory holds another \u2014 run the command that matches what is actually here.",
    source: "manifest",
    severity: "fatal"
  },
  PROJECT_EXISTS: {
    code: "AX-PROJECT-018",
    title: "Project Already Exists",
    description: "Scaffolding refused to overwrite a directory that already exists \u2014 remove it or pick a different name first.",
    source: "manifest",
    severity: "fatal"
  },
  TYPEGEN_NO_BLUEPRINT: {
    code: "AX-PROJECT-007",
    title: "Typegen Needs A Loaded Blueprint",
    description: "Agent-kind typegen was called without a blueprint \u2014 its declared surfaces are the source of the generated types.",
    source: "manifest",
    severity: "fatal"
  },
  DEPLOY_AGENTS_ONLY: {
    code: "AX-PROJECT-008",
    title: "Only Agents Can Deploy",
    description: "A module was asked to deploy on its own \u2014 modules only run installed inside an agent, deploy the agent instead.",
    source: "manifest",
    severity: "fatal"
  },
  PUBLISH_UNSUPPORTED_KIND: {
    code: "AX-PROJECT-009",
    title: "This Project Kind Cannot Publish Yet",
    description: "Only agents and modules publish to the registry today. Cognets and benches become first-class registry artifacts in the unified artifact work \u2014 until then, publishing one would register it under the wrong kind and claim its name in the shared namespace.",
    source: "manifest",
    severity: "fatal"
  },
  PREPARE_FROZEN_DRIFT: {
    code: "AX-PROJECT-014",
    title: "Dependencies Drifted From The Lockfile",
    description: "`--frozen` asserts that package.json, the lockfile and node_modules already agree. Something did not: a dependency is missing, at a version outside its declared range, or declared but no longer selected. Run `axon prepare` without --frozen to reconcile, and commit the result.",
    source: "manifest",
    severity: "fatal"
  },
  PUBLISH_VERIFY_FAILED: {
    code: "AX-PROJECT-013",
    title: "Artifact Does Not Compile",
    description: "The package was built, but compiling it the way a consumer would failed \u2014 so publishing it would ship something nobody can install. Usually a file the source imports was left out of the package. Published versions are immutable, so this is caught before upload rather than after.",
    source: "manifest",
    severity: "fatal"
  },
  DEPLOY_PROVISION_FAILED: {
    code: "AX-PROJECT-012",
    title: "Deployment Provisioning Failed",
    description: "The agent was published, but the cloud control plane could not provision its runtime. The request ID identifies the server-side failure.",
    source: "manifest",
    severity: "fatal"
  },
  DEPLOY_RUNTIME_FAILED: {
    code: "AX-PROJECT-013",
    title: "Agent Failed To Start",
    description: "Cloud infrastructure was provisioned, but the agent process failed during boot. The reported runtime diagnostic identifies the immediate cause.",
    source: "runtime",
    severity: "fatal"
  },
  DEPLOY_ENV_RESERVED: {
    code: "AX-PROJECT-014",
    title: "Reserved Deployment Variable",
    description: "The production .env file attempts to override a variable owned by the Axon runtime or Cloud Run.",
    source: "manifest",
    severity: "fatal"
  },
  DEPLOY_ENV_INVALID: {
    code: "AX-PROJECT-015",
    title: "Invalid Deployment Variable",
    description: "The production .env file contains a key that is not a valid environment variable name.",
    source: "manifest",
    severity: "fatal"
  },
  BUNDLE_MODULE_COLLISION: {
    code: "AX-PROJECT-019",
    title: "Module Name Collision",
    description: "A hard-imported source module's name collides with an already-installed registry module of the same name.",
    source: "manifest",
    severity: "fatal"
  },
  BUNDLE_INVALID: {
    code: "AX-PROJECT-010",
    title: "Invalid Bundle Source",
    description: "The directory being bundled has no package.json, or its package.json has no name \u2014 every bundle needs a real package identity.",
    source: "manifest",
    severity: "fatal"
  },
  BUNDLE_TAR_MISSING: {
    code: "AX-PROJECT-020",
    title: "tar Not Found",
    description: "Bundling shells out to the system's tar binary, which isn't on PATH \u2014 install Git for Windows or use WSL on that platform.",
    source: "manifest",
    severity: "fatal"
  },
  BUNDLE_TAR_FAILED: {
    code: "AX-PROJECT-021",
    title: "tar Failed",
    description: "The tar subprocess exited non-zero while building a bundle archive.",
    source: "manifest",
    severity: "fatal"
  },
  BENCH_RUN_NOT_FOUND: {
    code: "AX-BENCH-001",
    title: "Bench Run Not Found",
    description: "No recorded bench run exists with this id.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_NOT_FOUND: {
    code: "AX-BENCH-002",
    title: "Bench Not Found",
    description: "No bench.config.ts was found at this path \u2014 it isn't a recognized bench project.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_TESTS_NOT_FOUND: {
    code: "AX-BENCH-003",
    title: "Bench Test Files Not Found",
    description: "The bench config declares test files that don't exist on disk.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_LOCAL_REF_NOT_FOUND: {
    code: "AX-BENCH-004",
    title: "Bench Local Reference Not Found",
    description: "A factor variable references a local file/directory that doesn't exist.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_CONFIG_INVALID: {
    code: "AX-BENCH-005",
    title: "Bench Config Invalid",
    description: "bench.config.ts failed to evaluate or didn't produce a valid bench definition.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_PACKAGE_NOT_FOUND: {
    code: "AX-BENCH-006",
    title: "Bench Package Not Found",
    description: "No package.json exists at the bench root \u2014 every bench project needs one for identity.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_PACKAGE_NAME_REQUIRED: {
    code: "AX-BENCH-007",
    title: "Bench Package Name Required",
    description: "The bench's package.json has no name field.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_PACKAGE_VERSION_REQUIRED: {
    code: "AX-BENCH-008",
    title: "Bench Package Version Required",
    description: "The bench's package.json has no version field.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_CONTEXT_MISSING: {
    code: "AX-BENCH-009",
    title: "Bench Context Missing",
    description: "The benchmark preload needs AXON_BENCH_CONTEXT set \u2014 it was run outside the bench harness.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_NO_ACTIVE_CASE: {
    code: "AX-BENCH-010",
    title: "No Active Bench Case",
    description: "A bench emission (measurement, artifact) happened outside any running Bun test \u2014 these calls must occur inside a test case.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_WORKSPACE_UNAVAILABLE: {
    code: "AX-BENCH-011",
    title: "Bench Workspace Unavailable",
    description: "The bench's workspace directory hasn't been materialized yet for this run.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_AGENT_UNRESOLVED: {
    code: "AX-BENCH-012",
    title: "Bench Agent Unresolved",
    description: "The bench's declared subject agent isn't a prepared local agent \u2014 run `axon prepare` on it first.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_MEASUREMENT_UNKNOWN: {
    code: "AX-BENCH-013",
    title: "Unknown Bench Measurement",
    description: "A measurement was emitted under an id the bench config never declared.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_MEASUREMENT_TYPE: {
    code: "AX-BENCH-014",
    title: "Bench Measurement Type Mismatch",
    description: "A measurement's emitted value doesn't match the type its bench config declaration expects.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_MEASUREMENT_DOMAIN: {
    code: "AX-BENCH-015",
    title: "Bench Measurement Out Of Domain",
    description: "A measurement's emitted value falls outside the range or category the bench config declares for it.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_DIMENSION_UNKNOWN: {
    code: "AX-BENCH-016",
    title: "Unknown Bench Dimension",
    description: "A dimension value was set under an id the bench config never declared.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_DIMENSION_DOMAIN: {
    code: "AX-BENCH-017",
    title: "Bench Dimension Out Of Domain",
    description: "A dimension's set value isn't one of the categories its bench config declares.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_AXIS_UNKNOWN: {
    code: "AX-BENCH-018",
    title: "Unknown Bench Factor",
    description: "Something referenced a factor id the running bench's coordinate never assigned a value to.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_ARTIFACT_UNKNOWN: {
    code: "AX-BENCH-019",
    title: "Unknown Bench Artifact",
    description: "An artifact was emitted under an id the bench config never declared.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_ARTIFACT_MEDIA_TYPE: {
    code: "AX-BENCH-020",
    title: "Bench Artifact Media Type Not Allowed",
    description: "An artifact was emitted with a media type its bench config declaration doesn't allow.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_SCHEMA_UNREADABLE: {
    code: "AX-BENCH-030",
    title: "Bench Schema Unreadable",
    description: "bench.config.ts could not be parsed while extracting the measurement schema.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_SCHEMA_EMPTY: {
    code: "AX-BENCH-031",
    title: "Bench Schema Empty",
    description: "defineBench<Schema> was given a type with no properties \u2014 an empty schema and a failed extraction must never look alike.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_SCHEMA_UNSUPPORTED_TYPE: {
    code: "AX-BENCH-032",
    title: "Bench Measurement Type Unsupported",
    description: "A measurement is not a boolean, number, union of string literals, or string.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_SCHEMA_EXTRACTION_FAILED: {
    code: "AX-BENCH-033",
    title: "Bench Schema Extraction Failed",
    description: "The schema worker did not return a schema. Prepare fails rather than continuing with an empty one, which would silently make every measurement undeclared.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_AXIS_NOT_FOUND: {
    code: "AX-BENCH-021",
    title: "Bench Axis Not Found",
    description: "The bench config's matrix has no axis with this key.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_AXIS_VALUE_NOT_FOUND: {
    code: "AX-BENCH-022",
    title: "Bench Axis Value Not Found",
    description: "The bench config's matrix axis has no declared value with this id.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_WORKSPACE_ESCAPE: {
    code: "AX-BENCH-023",
    title: "Bench Workspace Path Escapes Root",
    description: "A workspace source entry resolved to a path outside the workspace directory \u2014 refused rather than materialized.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_WORKSPACE_SYMLINK_UNSUPPORTED: {
    code: "AX-BENCH-024",
    title: "Bench Workspace Symlinks Unsupported",
    description: "A workspace source contains a symlink \u2014 not supported when materializing a bench workspace.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_WORKSPACE_OUTSIDE_ROOT: {
    code: "AX-BENCH-025",
    title: "Bench Template Outside Root",
    description: "A workspace template's declared source path resolves outside the bench project root.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_WORKSPACE_SOURCE_NOT_FOUND: {
    code: "AX-BENCH-026",
    title: "Bench Template Not Found",
    description: "A workspace template's declared source path isn't a real directory.",
    source: "bench",
    severity: "fatal"
  },
  BENCH_LOG_INVALID: {
    code: "AX-BENCH-027",
    title: "Bench Log Invalid",
    description: "A bench run's event log is missing an entry its projection requires \u2014 the log is incomplete or was written out of order.",
    source: "bench",
    severity: "fatal"
  },
  TOOL_DECLARE_FAILED: {
    code: "AX-BLUEPRINT-002",
    title: "Tool Declaration Failed",
    description: "Compiling a src/tools/*.ts file's TypeScript declarations failed \u2014 the worker subprocess reported a compile error.",
    source: "manifest",
    severity: "fatal"
  },
  TOOL_BUNDLE_FAILED: {
    code: "AX-BLUEPRINT-006",
    title: "Tool Bundle Failed",
    description: "Bundling a src/tools/*.ts file to self-contained source failed \u2014 the bundler subprocess reported an error. Tools are bundled so the sandbox loads them without mounting the project; a bundle failure means the tool cannot enter the box.",
    source: "manifest",
    severity: "fatal"
  },
  ROUTE_LOAD_FAILED: {
    code: "AX-BLUEPRINT-007",
    title: "Route Load Failed",
    description: "A file in server/api/ could not be imported. The agent would serve an endpoint set that is not the declared one \u2014 a caller gets a 404 for a route whose file exists.",
    source: "manifest",
    severity: "fatal"
  },
  SCRIPT_LOAD_FAILED: {
    code: "AX-BLUEPRINT-008",
    title: "Script Load Failed",
    description: "A file in src/scripts/ could not be processed. `axon run <name>` would report the script as not found while its file sits in the project.",
    source: "manifest",
    severity: "fatal"
  },
  PLUGIN_LOAD_FAILED: {
    code: "AX-BLUEPRINT-009",
    title: "Plugin Load Failed",
    description: "A plugin could not be imported. Plugins wire server behaviour at boot; one silently missing means the agent runs without behaviour its author declared.",
    source: "manifest",
    severity: "fatal"
  },
  MIDDLEWARE_LOAD_FAILED: {
    code: "AX-BLUEPRINT-010",
    title: "Middleware Load Failed",
    description: "A middleware file could not be imported. Middleware commonly carries auth and validation, so a silently skipped one is a request path running without the checks its author wrote.",
    source: "manifest",
    severity: "fatal"
  },
  PROMPT_INTROSPECT_FAILED: {
    code: "AX-BLUEPRINT-011",
    title: "Prompt Introspection Failed",
    description: "A .vue prompt could not be introspected for its props. The prompt would render without the inputs it declares, or not at all.",
    source: "manifest",
    severity: "fatal"
  },
  CONFIG_NOT_FOUND: {
    code: "AX-BLUEPRINT-003",
    title: "Config Not Found",
    description: "No axon.config.ts exists at this path.",
    source: "manifest",
    severity: "fatal"
  },
  CONFIG_LOAD_FAILED: {
    code: "AX-BLUEPRINT-004",
    title: "Config Failed To Load",
    description: "axon.config.ts threw or failed to evaluate \u2014 check the file for a syntax or runtime error.",
    source: "manifest",
    severity: "fatal"
  },
  CONFIG_INVALID: {
    code: "AX-BLUEPRINT-005",
    title: "Config Invalid",
    description: "axon.config.ts evaluated but never called defineAgent() \u2014 every agent config must produce one.",
    source: "manifest",
    severity: "fatal"
  },
  ENGINE_NO_DONE: {
    code: "AX-KERNEL-001",
    title: "Engine Stream Ended Without Completing",
    description: "The model driver's stream ended without ever emitting a completion event \u2014 the engine likely disconnected or crashed mid-response.",
    source: "kernel",
    severity: "fatal"
  },
  ENGINE_STREAM_FAILED: {
    code: "AX-KERNEL-008",
    title: "Engine Stream Failed",
    description: "The model driver's stream failed and exhausted its retries (or the failure wasn't retryable) \u2014 see context for the provider's fault code.",
    source: "kernel",
    severity: "fatal"
  },
  CODEX_NOT_CONNECTED: {
    code: "AX-KERNEL-012",
    title: "Codex Subscription Not Connected",
    description: "This agent uses a Codex model, but your Axon account is not connected to ChatGPT \u2014 run :provider codex connect and try again.",
    source: "kernel",
    severity: "fatal"
  },
  RUN_IN_PROGRESS: {
    code: "AX-KERNEL-002",
    title: "A Wake Is Already Running",
    description: "The kernel only executes one wake at a time \u2014 a new run was requested while the previous one was still active.",
    source: "kernel",
    severity: "recovered"
  },
  RUN_RESERVATION_EXPIRED: {
    code: "AX-KERNEL-003",
    title: "Wake Reservation Expired",
    description: "The reserved execution slot for this wake is no longer active \u2014 it was released before the run could start.",
    source: "kernel",
    severity: "fatal"
  },
  NO_COGNET_LOADED: {
    code: "AX-KERNEL-004",
    title: "No Cognet Loaded",
    description: "The kernel tried to execute a wake, but the blueprint carried no cognet definition to run it against.",
    source: "kernel",
    severity: "fatal"
  },
  SYSCALL_OUTSIDE_RUN: {
    code: "AX-KERNEL-005",
    title: "Syscall Outside An Active Run",
    description: "A kernel syscall (engine.stream and similar) was made with no active wake to attribute it to.",
    source: "kernel",
    severity: "fatal"
  },
  CAPSULE_ACCESSED_BEFORE_BOOT: {
    code: "AX-KERNEL-007",
    title: "Capsule Accessed Before Boot",
    description: "Something reached for the live capsule instance before boot() had run \u2014 there is no sandbox yet to hand back.",
    source: "kernel",
    severity: "fatal"
  },
  COGNET_EMIT_FORBIDDEN: {
    code: "AX-KERNEL-009",
    title: "Cognet Emit Forbidden",
    description: "A cognet tried to emit an event outside the cognet:* namespace \u2014 the ABI only lets a cognet narrate its own telemetry, never forge kernel machinery events.",
    source: "kernel",
    severity: "fatal"
  },
  SCHEDULER_MODE_MISMATCH: {
    code: "AX-KERNEL-010",
    title: "Scheduler Mode Mismatch",
    description: "A caller used the wrong wake verb for the cognet's mode: continuous cognets advance via tick(), driven by the body's clock; invocation cognets wake on a stimulus via request()/stream().",
    source: "kernel",
    severity: "fatal"
  },
  THREAD_UNKNOWN_PARENT: {
    code: "AX-SESSION-001",
    title: "Thread Branched From Unknown Parent",
    description: "A thread's recorded lineage points at a parent thread id that isn't registered in this session \u2014 the session index is inconsistent.",
    source: "thread",
    severity: "fatal"
  },
  THREAD_NOT_FOUND: {
    code: "AX-SESSION-002",
    title: "Thread Not Found",
    description: "The requested thread id isn't registered in this session.",
    source: "thread",
    severity: "fatal"
  },
  THREAD_BRANCH_UNKNOWN: {
    code: "AX-SESSION-003",
    title: "Cannot Branch Unknown Thread",
    description: "A branch was requested from a parent thread id that isn't registered in this session.",
    source: "thread",
    severity: "fatal"
  },
  NO_COGNET: {
    code: "AX-BLUEPRINT-001",
    title: "No Cognet Declared",
    description: "The blueprint carries no cognet definition \u2014 an agent cannot run without a brain. The CLI or test harness must construct and pass one.",
    source: "runtime",
    severity: "fatal"
  },
  CONTROL_PATH_NOT_FOUND: {
    code: "AX-CONTROL-001",
    title: "Control Path Not Found",
    description: "A control-channel call named a method the peer does not expose. The two ends disagree about the surface \u2014 usually a TUI and an extension built from different versions.",
    source: "server",
    severity: "fatal"
  },
  CONTROL_PATH_NOT_CALLABLE: {
    code: "AX-CONTROL-002",
    title: "Control Path Not Callable",
    description: "A control-channel call resolved to a value on the peer's handle that is not a function.",
    source: "server",
    severity: "fatal"
  },
  CONTROL_CALL_FAILED: {
    code: "AX-CONTROL-003",
    title: "Control Call Failed",
    description: "The peer served a control-channel call and it threw. The remote message is carried here \u2014 the failure surfaces at the local call site rather than being returned as a falsy value.",
    source: "server",
    severity: "fatal"
  },
  CONTROL_CLOSED: {
    code: "AX-CONTROL-004",
    title: "Control Channel Closed",
    description: "A control-channel call was made, or was still in flight, when the channel closed. In-flight calls reject on close rather than hanging forever on an answer that is no longer coming.",
    source: "server",
    severity: "fatal"
  },
  CONTROL_UNAUTHORIZED: {
    code: "AX-CONTROL-005",
    title: "Control Handshake Rejected",
    description: "A connection to the control socket presented a missing or incorrect token. The token lives in the instance record, which is readable only by the owning user \u2014 a mismatch means the caller is not the local Fleet extension.",
    source: "server",
    severity: "fatal"
  },
  PLUGIN_BOOT_FAILED: {
    code: "AX-SERVER-001",
    title: "Plugin Failed During Boot",
    description: "A server plugin threw while running at boot \u2014 plugins are the one place in server startup where a failure must abort the boot rather than being warned and skipped.",
    source: "server",
    severity: "fatal"
  },
  HANDLE_SHUTDOWN_FAILED: {
    code: "AX-RUNTIME-002",
    title: "Handle Failed To Shut Down",
    description: "One of the runtime's owned handles (kernel, etc.) threw during shutdown \u2014 teardown is error-isolated, so the others still ran, but this one didn't close cleanly.",
    source: "runtime",
    severity: "fatal"
  },
  BUS_HANDLER_FAILED: {
    code: "AX-RUNTIME-004",
    title: "Bus Handler Failed",
    description: "A handler subscribed to a runtime bus event threw. Handler failures are non-fatal by design \u2014 the remaining handlers still run \u2014 but they are recorded rather than swallowed, since plugins and modules register handlers and a silently-broken one is invisible rot.",
    source: "runtime",
    severity: "degraded"
  },
  TOOL_CALL_FAILED: {
    code: "AX-RUNTIME-003",
    title: "Tool Call Failed",
    description: "An axon.tools.<namespace>.<fn>() call from script-land completed with a non-ok result from the capsule \u2014 unwrapped here into a normal throw, since script-land expects the ordinary call/throw contract, not the kernel's own stable-result shape.",
    source: "runtime",
    severity: "fatal"
  },
  CAPSULE_TOOL_TIMEOUT: {
    code: "AX-CAPSULE-001",
    title: "Tool Load Timed Out",
    description: "The sandbox never confirmed loading a declared tool within the timeout \u2014 it may be stuck on a slow import or the subprocess is unresponsive.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_TOOL_SCOPE_MISMATCH: {
    code: "AX-CAPSULE-002",
    title: "Tool Scope Mismatch",
    description: "A tool's declared exports don't match what it actually exported once loaded in the sandbox \u2014 the bundled source and its declaration have drifted apart.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_TOOL_FAILED: {
    code: "AX-CAPSULE-003",
    title: "Tool Failed To Load",
    description: "A declared tool failed to load into the sandbox \u2014 its source may be malformed, too large to import, or the subprocess exited before confirming.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_CONFINE_UNAVAILABLE: {
    code: "AX-CAPSULE-004",
    title: "OS Confinement Unavailable",
    description: "The policy requested OS confinement (isolation: auto) but the host is missing a required primitive (bubblewrap, systemd, nft, or the axon-agent user). Run `axon install`, or set isolation: none to opt out explicitly. The capsule refuses to boot rather than silently run unconfined.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_CONFINE_USER_UNRESOLVED: {
    code: "AX-CAPSULE-005",
    title: "Confinement User Unresolved",
    description: "The confinement user exists but its numeric uid/gid could not be read \u2014 the box cannot drop privileges without them. The host user database may be inconsistent.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_BOOT_FAILED: {
    code: "AX-CAPSULE-006",
    title: "Capsule Failed To Boot",
    description: "The sandbox subprocess exited or reported failure before completing the boot handshake. The captured stderr in the error context is the real cause \u2014 most often a confinement mount that could not be satisfied (a declared fs path that does not exist) or a runtime that could not start.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_BOOT_TIMEOUT: {
    code: "AX-CAPSULE-007",
    title: "Capsule Boot Timed Out",
    description: "The sandbox subprocess did not report ready within the boot timeout. Its captured stderr is in the error context; if empty, the subprocess may be hung rather than crashed.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_SPAWN_FAILED: {
    code: "AX-CAPSULE-008",
    title: "Capsule Spawn Failed",
    description: "The capsule subprocess command could not be spawned at all \u2014 the interpreter or confinement wrapper was not found, or PATH is unset. Check that bun (and, under confinement, bwrap/systemd-run) are on PATH.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_WIRE_CLOSED: {
    code: "AX-CAPSULE-009",
    title: "Capsule Wire Closed",
    description: "A command was sent to the sandbox after its stdin pipe was gone \u2014 the subprocess has exited or is mid-teardown. The caller is racing the capsule lifecycle.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_DOWN: {
    code: "AX-CAPSULE-010",
    title: "No Live Capsule",
    description: "An operation needed a running sandbox subprocess, but none is live \u2014 it is booting, restarting after a crash, or has been declared dead.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_ALREADY_BOOTED: {
    code: "AX-CAPSULE-011",
    title: "Capsule Already Booted",
    description: "boot() was called on a capsule that already has a live subprocess. Boot is once per lifetime; use update()/reload() to replace a running incarnation.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_INSTALL_FAILED: {
    code: "AX-CAPSULE-013",
    title: "Confinement Install Failed",
    description: "Provisioning the host for the hardened confinement tier failed \u2014 most often because creating the dedicated system user needs root. Re-run `axon install` with sufficient privilege.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_HOST_UNAVAILABLE: {
    code: "AX-CAPSULE-014",
    title: "Host Bridge Unavailable",
    description: "Sandboxed code called a host service, but this capsule was built with no host provider. Host calls require a wired host bridge on the manager side.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_CRASHED: {
    code: "AX-CAPSULE-015",
    title: "Capsule Crashed",
    description: "An unhandled error escaped inside the sandbox subprocess. The capsule reports it on the wire and exits immediately \u2014 after an unhandled throw the sandbox's state is unknown, and a capsule that keeps serving is worse than one that dies loudly.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_DEAD: {
    code: "AX-CAPSULE-016",
    title: "Capsule Dead",
    description: "The capsule subprocess is gone and supervision gave up restarting it. Every subsequent execution request fails until a new capsule is booted.",
    source: "capsule",
    severity: "fatal"
  },
  CAPSULE_PARSE_ERROR: {
    code: "AX-CAPSULE-017",
    title: "Capsule Wire Parse Error",
    description: "A line arriving from the sandbox was not a valid protocol event. The sandbox is speaking garbage \u2014 a protocol mismatch or corrupted output \u2014 and the line is dropped rather than acted on, never silently.",
    source: "capsule",
    severity: "degraded"
  },
  CAPSULE_CMD_FAILED: {
    code: "AX-CAPSULE-018",
    title: "Capsule Command Failed",
    description: "Code executed in the sandbox threw. This is the ordinary failure path for an agent-emitted block or a script-land run() \u2014 the error is the sandboxed code's own, surfaced verbatim.",
    source: "capsule",
    severity: "degraded"
  },
  CAPSULE_FN_FAILED: {
    code: "AX-CAPSULE-019",
    title: "Tool Call Threw",
    description: "A mediated tool function threw inside the sandbox. The failure is the tool's own; it propagates to the calling code unchanged and is recorded as the closing half of the call's span.",
    source: "capsule",
    severity: "degraded"
  },
  CAPSULE_PROC_DENIED: {
    code: "AX-CAPSULE-020",
    title: "Process Spawn Denied",
    description: "A process the sandbox tried to start was refused \u2014 denied by policy, killed before it could spawn, or the spawn itself failed. No process was created.",
    source: "capsule",
    severity: "degraded"
  },
  CAPSULE_PROC_FAILED: {
    code: "AX-CAPSULE-022",
    title: "Managed Process Failed",
    description: "A spawned child process errored without ever producing an exit code \u2014 an exec failure or a broken IPC channel. Distinct from a non-zero exit, which is the process running correctly and reporting a result.",
    source: "capsule",
    severity: "degraded"
  },
  CAPSULE_PROC_STDIN_FAILED: {
    code: "AX-CAPSULE-021",
    title: "Process Stdin Write Failed",
    description: "Writing to a managed child process's stdin failed \u2014 the process is no longer running, or its stdin has already closed.",
    source: "capsule",
    severity: "degraded"
  },
  NOT_BOOTED: {
    code: "AX-TUI-001",
    title: "No Agent Running",
    description: "A message was sent, or an action requiring a live agent was taken, before any agent finished booting.",
    source: "tui",
    severity: "fatal"
  },
  NOT_AUTHENTICATED: {
    code: "AX-TUI-002",
    title: "Not Logged In",
    description: "The action needs an active profile, but none is logged in yet.",
    source: "tui",
    severity: "fatal"
  },
  PROFILE_NOT_AUTHENTICATED: {
    code: "AX-TUI-003",
    title: "Profile Has No Session",
    description: "The target profile exists but has no stored session \u2014 it has never logged in, or its session was cleared.",
    source: "tui",
    severity: "fatal"
  },
  PROFILE_UNKNOWN: {
    code: "AX-TUI-004",
    title: "Unknown Profile",
    description: "The requested profile id isn't one of the profiles stored on this machine.",
    source: "tui",
    severity: "fatal"
  },
  SESSION_ALREADY_RUNNING: {
    code: "AX-TUI-005",
    title: "Session Is Already Running",
    description: "spawn() was asked to resume a session that already has a live instance. Focus the running instance instead of booting a second runtime over the same log.",
    source: "tui",
    severity: "fatal"
  },
  SESSION_NOT_RUNNING: {
    code: "AX-TUI-016",
    title: "Session Is Not Running",
    description: "focus() was pointed at a sessionId with no live instance behind it. Spawn (or resume) it first \u2014 focus is pure selection over running instances.",
    source: "tui",
    severity: "fatal"
  },
  NO_FOCUSED_INSTANCE: {
    code: "AX-TUI-017",
    title: "No Focused Agent Instance",
    description: "A module install/uninstall was requested with no running agent instance focused \u2014 spawn or focus one first.",
    source: "tui",
    severity: "fatal"
  },
  MODULE_INSTALL_FAILED: {
    code: "AX-TUI-018",
    title: "Module Install Failed",
    description: "The registry installer returned an error for this module specifier \u2014 check the specifier and registry connectivity.",
    source: "tui",
    severity: "fatal"
  },
  NO_MODULES_INSTALLED: {
    code: "AX-TUI-019",
    title: "No Modules Installed",
    description: "The :uninstall command was opened with no modules resolved into the focused instance's blueprint.",
    source: "tui",
    severity: "fatal"
  },
  BASE_UNMANAGED: {
    code: "AX-TUI-006",
    title: "Base Config Not Platform-Managed",
    description: "The managed base workspace's config exists on disk but carries no platform manifest \u2014 it wasn't created by the platform and won't be overwritten automatically.",
    source: "tui",
    severity: "fatal"
  },
  BASE_CONFIG_MODIFIED: {
    code: "AX-TUI-007",
    title: "Base Config Edited By Hand",
    description: "The managed base workspace's config no longer matches the hash the platform recorded \u2014 someone edited it directly, so the platform refuses to overwrite it.",
    source: "tui",
    severity: "fatal"
  },
  DEPLOYMENT_NOT_CONNECTABLE: {
    code: "AX-TUI-028",
    title: "Deployment Not Connectable",
    description: "The deployment is not in the connectable list \u2014 it may have stopped, errored, or never finished provisioning. Refresh the deployment list and try again.",
    source: "tui",
    severity: "fatal"
  },
  SUBAGENT_REMOTE_PARENT: {
    code: "AX-TUI-027",
    title: "Cannot Spawn A Subagent From A Deployment",
    description: "A subagent is forked from its parent's local project, and an attached deployment has no local project here \u2014 the deployed agent runs its own subagents inside its own capsule.",
    source: "tui",
    severity: "fatal"
  },
  BASE_MODEL_INSTANCE_CONFLICT: {
    code: "AX-TUI-026",
    title: "Managed Model Instance Already Running",
    description: "A managed base instance is already running on a different engine. The base workspace holds one shared config, so spawning a second naked model would rewrite it underneath the live instance \u2014 close the running one first.",
    source: "tui",
    severity: "fatal"
  },
  NOT_WIRED: {
    code: "AX-TUI-008",
    title: "Not Wired Yet",
    description: "This surface is a declared stub \u2014 the real implementation hasn't been built yet.",
    source: "tui",
    severity: "fatal"
  },
  MIC_ALREADY_CAPTURING: {
    code: "AX-TUI-009",
    title: "Mic Already Capturing",
    description: "capture.start() was called while a capture was already in progress \u2014 stop the current one first.",
    source: "tui",
    severity: "fatal"
  },
  MIC_CAPTURE_UNAVAILABLE: {
    code: "AX-TUI-010",
    title: "No Audio Capture Tool Found",
    description: "Voice input needs one of arecord, sox, or ffmpeg installed and on PATH.",
    source: "tui",
    severity: "fatal"
  },
  MIC_FFT_SIZE_MISMATCH: {
    code: "AX-TUI-014",
    title: "FFT Sample Size Mismatch",
    description: "computeBuckets() was called with a sample buffer that isn't exactly config.fftSize long \u2014 an internal invariant, callers must pad/trim first.",
    source: "tui",
    severity: "fatal"
  },
  MIC_CAPTURE_FAILED: {
    code: "AX-TUI-015",
    title: "Mic Capture Failed",
    description: "The audio capture subprocess produced no output or exited immediately \u2014 check that a microphone is available.",
    source: "tui",
    severity: "fatal"
  },
  WATCH_PATH_REQUIRED: {
    code: "AX-TUI-021",
    title: "Watch Path Required",
    description: "`axon watch`/`axon unwatch` need a directory argument.",
    source: "tui",
    severity: "fatal"
  },
  WATCH_PATH_NOT_FOUND: {
    code: "AX-TUI-022",
    title: "Watch Path Not Found",
    description: "`axon watch` was given a directory that doesn't exist on disk.",
    source: "tui",
    severity: "fatal"
  },
  EDITOR_NOT_SET: {
    code: "AX-TUI-023",
    title: "No Editor Configured",
    description: "`axon settings` needs the $EDITOR environment variable set to know which editor to open.",
    source: "tui",
    severity: "fatal"
  },
  EDITOR_LAUNCH_FAILED: {
    code: "AX-TUI-024",
    title: "Editor Failed To Launch",
    description: "The command in $EDITOR could not be spawned \u2014 check that it's installed and on PATH.",
    source: "tui",
    severity: "fatal"
  },
  WATCH_AND_INIT_ARGS_REQUIRED: {
    code: "AX-TUI-025",
    title: "Directory And Name Required",
    description: `The init palette's "watch a new directory" entry needs both a directory path and an agent name, space-separated.`,
    source: "tui",
    severity: "fatal"
  },
  MODULE_CONFIG_LOAD_FAILED: {
    code: "AX-MODULE-001",
    title: "Module Config Failed To Load",
    description: "The runtime could not import a module's module.config.ts at boot \u2014 the file is missing at its resolved path, or importing it threw. A module that cannot load contributes nothing, so boot fails rather than run a partially-wired agent.",
    source: "runtime",
    severity: "fatal"
  },
  MODULE_OPTIONS_INVALID: {
    code: "AX-MODULE-002",
    title: "Invalid Module Options",
    description: "The options declared for a module under modules.<name> in axon.config.ts do not satisfy the module's options schema \u2014 a required option is missing or a value has the wrong type.",
    source: "runtime",
    severity: "fatal"
  },
  MODULE_SETUP_FAILED: {
    code: "AX-MODULE-003",
    title: "Module Setup Failed",
    description: "A module's setup() threw during agent boot. Setup runs sequentially in blueprint order and a failure is total \u2014 no later module is wired, and the agent does not boot half-configured.",
    source: "runtime",
    severity: "fatal"
  },
  MODULE_SERVER_NOT_WIRED: {
    code: "AX-MODULE-004",
    title: "Module Server API Not Wired",
    description: "A module's setup() called ctx.server.addRoute/addMiddleware or ctx.tools.get, but that surface is not implemented yet. Declare routes as server/api/ files in the module instead.",
    source: "runtime",
    severity: "fatal"
  },
  MODULE_ENV_REQUIRED: {
    code: "AX-MODULE-005",
    title: "Module Env Var Missing",
    description: "A module's setup() called ctx.env.require() for a variable the agent's resolved environment does not provide. The module declares required env in module.config.ts; the agent must supply it (e.g. in .env).",
    source: "runtime",
    severity: "fatal"
  },
  MODULE_POLICY_IMMUTABLE: {
    code: "AX-MODULE-006",
    title: "Module Policy Is Immutable At Boot",
    description: "A module's setup() called ctx.policy.update(). The resolved agent policy is authoritative and cannot be mutated at boot \u2014 declare policy needs statically in module.config.ts so the CLI reconciles them at install.",
    source: "runtime",
    severity: "fatal"
  },
  CLONE_REF_REQUIRED: {
    code: "AX-PROJECT-022",
    title: "No Artifact Named",
    description: "`axon clone` was run without an artifact to clone. Name one, for example: axon clone @axon/arxiv",
    source: "cli",
    severity: "fatal"
  },
  FORK_REF_REQUIRED: {
    code: "AX-PROJECT-023",
    title: "No Artifact Named",
    description: "`axon fork` was run without an artifact to fork. Name one, for example: axon fork @axon/arxiv --as @you/arxiv",
    source: "cli",
    severity: "fatal"
  },
  FORK_NAME_REQUIRED: {
    code: "AX-PROJECT-024",
    title: "Fork Needs A New Name",
    description: "A fork is published under your own namespace, so it needs a name: pass --as <package-name>, for example: axon fork @axon/arxiv --as @you/arxiv",
    source: "cli",
    severity: "fatal"
  },
  CLONE_TARGET_EXISTS: {
    code: "AX-PROJECT-025",
    title: "Clone Target Not Empty",
    description: "The directory the artifact would be cloned into already has files in it. Clone into a new directory, or clear this one first.",
    source: "cli",
    severity: "fatal"
  },
  ARTIFACT_DOWNLOAD_FAILED: {
    code: "AX-PROJECT-026",
    title: "Artifact Download Failed",
    description: "The registry did not serve the artifact's source archive. The version may have been unpublished, or the network request failed.",
    source: "cli",
    severity: "fatal"
  },
  ARTIFACT_EXTRACT_FAILED: {
    code: "AX-PROJECT-027",
    title: "Artifact Extract Failed",
    description: "The downloaded archive could not be unpacked. It may be truncated, or `tar` is unavailable on this machine.",
    source: "cli",
    severity: "fatal"
  },
  VERSION_INVALID: {
    code: "AX-PROJECT-028",
    title: "Invalid Version",
    description: "The project's package.json version is not valid semver, so the next version cannot be derived from it. Fix the version field by hand.",
    source: "cli",
    severity: "fatal"
  },
  FRAMEWORK_NOT_INSTALLED: {
    code: "AX-PROJECT-029",
    title: "Framework Packages Not Installed",
    description: "The generated type frame references @arcforge/types, @arcforge/engines and h3, none of which resolve from this project. Run `bun install` before `axon prepare`.",
    source: "cli",
    severity: "fatal"
  },
  CONFIG_EVALUATION_ESCAPED: {
    code: "AX-PROJECT-030",
    title: "defineAgent() Called Outside Config Evaluation",
    description: "defineAgent() ran outside the loader that evaluates axon.config.ts \u2014 it is a declaration helper, not a runtime function, and cannot be called from application code.",
    source: "cli",
    severity: "fatal"
  },
  PORT_UNAVAILABLE: {
    code: "AX-PROJECT-031",
    title: "No Free Port",
    description: "Every port in the range the agent scanned is already in use. Stop whatever is holding them, or start the agent on a different port.",
    source: "cli",
    severity: "fatal"
  },
  PARENT_INSTANCE_NOT_RUNNING: {
    code: "AX-RUNTIME-005",
    title: "Parent Agent Not Running",
    description: "A subagent was requested against a parent session that is no longer live \u2014 the parent shut down, crashed, or was never booted by this process.",
    source: "runtime",
    severity: "fatal"
  },
  SUBAGENT_DEPTH_EXCEEDED: {
    code: "AX-RUNTIME-006",
    title: "Subagent Depth Limit Reached",
    description: "An agent tried to spawn a subagent beyond the maximum nesting depth. The limit exists so a recursive delegation cannot spawn processes without bound.",
    source: "runtime",
    severity: "fatal"
  },
  SUBAGENT_CHILD_LIMIT_EXCEEDED: {
    code: "AX-RUNTIME-007",
    title: "Subagent Child Limit Reached",
    description: "One agent tried to hold more live children than the limit allows. Existing children must finish before more can be spawned.",
    source: "runtime",
    severity: "fatal"
  },
  SUBAGENT_DESCENDANT_LIMIT_EXCEEDED: {
    code: "AX-RUNTIME-008",
    title: "Subagent Descendant Limit Reached",
    description: "The whole subagent tree beneath one root exceeded its live-descendant budget. The limit bounds total concurrent processes, not just direct children.",
    source: "runtime",
    severity: "fatal"
  },
  SUBAGENT_REQUEST_INVALID: {
    code: "AX-RUNTIME-009",
    title: "Malformed Subagent Request",
    description: "A subagent request did not carry a usable prompt. It must be an object with `prompt` as a string or an array of strings.",
    source: "runtime",
    severity: "fatal"
  },
  INSTANCE_NOT_LOCAL: {
    code: "AX-RUNTIME-010",
    title: "Agent Instance Is Not Local",
    description: "An operation that only works against a locally booted agent was given a remote one. Subagent spawning and the managed base workspace both require a local process.",
    source: "runtime",
    severity: "fatal"
  },
  HOST_METHOD_UNKNOWN: {
    code: "AX-RUNTIME-011",
    title: "Unknown Host Method",
    description: "A booted agent called a host method this platform does not implement. The agent's framework version is likely newer than the CLI running it.",
    source: "runtime",
    severity: "fatal"
  },
  UPDATE_CURRENT_VERSION_INVALID: {
    code: "AX-TUI-029",
    title: "Running Version Is Not Semver",
    description: "The version this app reports for itself is not valid semver, so it cannot be compared against the latest release.",
    source: "cli",
    severity: "fatal"
  },
  UPDATE_RELEASE_INVALID: {
    code: "AX-TUI-030",
    title: "Malformed Release Record",
    description: "The backend's release record did not describe a valid @arcforge/axon `latest` version, so there is nothing safe to update to.",
    source: "cli",
    severity: "fatal"
  },
  UPDATE_UNAVAILABLE_IN_DEVELOPMENT: {
    code: "AX-TUI-031",
    title: "Update Not Available Here",
    description: "Self-update needs the packaged update helper and a supervisor request path, neither of which exists in a source checkout. Update the installed app instead.",
    source: "cli",
    severity: "fatal"
  },
  UPDATE_SUPERVISOR_UNAVAILABLE: {
    code: "AX-TUI-032",
    title: "Update Supervisor Unavailable",
    description: "The running app has no supervisor request path, so it cannot hand an update off to be applied after exit.",
    source: "cli",
    severity: "fatal"
  },
  UPDATE_HELPER_ARGS_INVALID: {
    code: "AX-TUI-033",
    title: "Malformed Update Helper Arguments",
    description: "The update helper was invoked without the --from/--to/--bun/--axon/--state arguments it requires. It is spawned by the app, not run by hand.",
    source: "cli",
    severity: "fatal"
  },
  UPDATE_HELPER_VERSION_INVALID: {
    code: "AX-TUI-034",
    title: "Update Helper Given Bad Versions",
    description: "The update helper received a --from or --to value that is not valid semver, so it refused to install anything.",
    source: "cli",
    severity: "fatal"
  },
  TEST_FILES_NOT_FOUND: {
    code: "AX-TUI-035",
    title: "No Test Files Matched",
    description: "No files matched the requested test patterns, so there was nothing to run. Check the pattern, or the directory it was resolved against.",
    source: "cli",
    severity: "fatal"
  },
  OLLAMA_UNAVAILABLE: {
    code: "AX-TUI-037",
    title: "Ollama Is Not Running",
    description: "No Ollama daemon answered on this machine. Start it with `ollama serve`, or install Ollama from https://ollama.com to run models locally.",
    source: "cli",
    severity: "fatal"
  },
  OLLAMA_REQUEST_FAILED: {
    code: "AX-TUI-038",
    title: "Ollama Request Failed",
    description: "The local Ollama daemon is running but refused a request \u2014 most often an unknown model name. The daemon's own message is included.",
    source: "cli",
    severity: "fatal"
  },
  OLLAMA_REGISTRY_UNREACHABLE: {
    code: "AX-TUI-039",
    title: "Ollama Registry Unreachable",
    description: "Could not reach the Ollama model registry to look a model up. Downloading needs a network connection; models already on disk still work offline.",
    source: "cli",
    severity: "fatal"
  },
  OLLAMA_PULL_FAILED: {
    code: "AX-TUI-040",
    title: "Model Download Failed",
    description: "Ollama could not finish downloading the model. The name may not exist in the registry, or the transfer was interrupted \u2014 a retry resumes from whatever was already fetched.",
    source: "cli",
    severity: "fatal"
  },
  TEST_PRELOAD_MISSING: {
    code: "AX-TUI-036",
    title: "Test API Loaded Without Its Preload",
    description: "The instrumented test API was imported without the preload that installs it. Tests must run through `axon test`, which wires the preload.",
    source: "cli",
    severity: "fatal"
  }
};

// node_modules/@arcforge/err/src/stack.ts
import { readFileSync } from "fs";
var FRAME_PATTERN_NAMED = /at\s+(.*?)\s+\((.*?):(\d+):(\d+)\)/;
var FRAME_PATTERN_BARE = /at\s+(.*?):(\d+):(\d+)/;
var IGNORED_PATH_SEGMENTS = ["node_modules", "native:", "internal", "bun:"];
var CONTEXT_LINES = 2;
function captureStack(skipFrames = 1) {
  const raw = new Error().stack;
  if (!raw)
    return [];
  const lines = raw.split(`
`).slice(1 + skipFrames);
  return lines.map(parseLine).filter(isRealFrame).map(withSource);
}
function parseStack(raw) {
  return raw.split(`
`).slice(1).map(parseLine).filter(isRealFrame).map(withSource);
}
function firstRealFrame(raw) {
  if (!raw)
    return null;
  return parseStack(raw)[0] ?? null;
}
function parseLine(line) {
  const named = line.match(FRAME_PATTERN_NAMED);
  if (named) {
    const [, fn, file, ln, col] = named;
    return { functionName: fn ?? null, fileName: file ?? null, lineNumber: numberOr(ln), columnNumber: numberOr(col) };
  }
  const bare = line.match(FRAME_PATTERN_BARE);
  if (bare) {
    const [, file, ln, col] = bare;
    return { functionName: null, fileName: file ?? null, lineNumber: numberOr(ln), columnNumber: numberOr(col) };
  }
  return { functionName: null, fileName: null, lineNumber: null, columnNumber: null };
}
function numberOr(value) {
  if (value === undefined)
    return null;
  const n = parseInt(value, 10);
  return Number.isNaN(n) ? null : n;
}
function isRealFrame(frame) {
  if (!frame.fileName)
    return false;
  return !IGNORED_PATH_SEGMENTS.some((segment) => frame.fileName.includes(segment));
}
function withSource(frame) {
  return { ...frame, source: readSourceWindow(frame.fileName, frame.lineNumber) };
}
function readSourceWindow(fileName, lineNumber) {
  if (!fileName || lineNumber === null)
    return null;
  let text;
  try {
    text = readFileSync(fileName, "utf-8");
  } catch {
    return null;
  }
  const lines = text.split(`
`);
  const targetIdx = lineNumber - 1;
  if (targetIdx < 0 || targetIdx >= lines.length)
    return null;
  const from = Math.max(0, targetIdx - CONTEXT_LINES);
  const to = Math.min(lines.length - 1, targetIdx + CONTEXT_LINES);
  const window2 = [];
  for (let i = from;i <= to; i++)
    window2.push({ lineNumber: i + 1, text: lines[i] ?? "" });
  return window2;
}

// node_modules/@arcforge/err/src/render.ts
function renderFrame(frame) {
  if (!frame.fileName || frame.lineNumber === null) {
    return frame.functionName ? `at ${frame.functionName}` : "at <unknown>";
  }
  const location = `${frame.fileName}:${frame.lineNumber}:${frame.columnNumber ?? 0}`;
  const header = frame.functionName ? `at ${frame.functionName} (${location})` : `at ${location}`;
  const snippet = frame.source ? renderSnippet(frame.source, frame.lineNumber, frame.columnNumber) : null;
  return snippet ? `${header}
${snippet}` : header;
}
var RULE_WIDTH = 80;
function renderError(error) {
  const lines = [`Axon Error: ${error.title}`, error.description];
  if (error.message && error.message !== error.title) {
    lines.push("", error.message);
  }
  if (error.context && Object.keys(error.context).length > 0) {
    lines.push("", "Context:", indent(renderContext(error.context)));
  }
  lines.push("\u2500".repeat(RULE_WIDTH), ...error.frames.map(renderFrame));
  if (error.cause !== undefined) {
    lines.push("", "Caused by:", indent(causeMessage(error.cause)));
  }
  return ["", lines.join(`
`), ""].join(`
`);
}
function renderContext(context) {
  return Object.entries(context).map(([key, value]) => `${key}: ${typeof value === "string" ? value : safeStringify(value)}`).join(`
`);
}
function safeStringify(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}
function causeMessage(cause) {
  return cause instanceof Error ? cause.stack ?? cause.message : String(cause);
}
function indent(text) {
  return text.split(`
`).map((line) => `  ${line}`).join(`
`);
}
function renderSnippet(source, lineNumber, columnNumber) {
  if (!source || source.length === 0)
    return null;
  const gutterWidth = String(source[source.length - 1].lineNumber).length;
  const rendered = [];
  for (const line of source) {
    const num = String(line.lineNumber).padStart(gutterWidth, " ");
    const marker = line.lineNumber === lineNumber ? ">" : " ";
    rendered.push(`  ${marker} ${num} | ${line.text}`);
    if (line.lineNumber === lineNumber && columnNumber !== null) {
      const caretPad = " ".repeat(gutterWidth + 6 + Math.max(0, columnNumber - 1));
      rendered.push(`${caretPad}^`);
    }
  }
  return rendered.join(`
`);
}

// node_modules/@arcforge/err/src/sink.ts
import { AsyncLocalStorage } from "async_hooks";
var storage = new AsyncLocalStorage;
function emitError(error) {
  storage.getStore()?.(error);
}

// node_modules/@arcforge/err/src/err.ts
function isAxonError(value) {
  return value instanceof Error && value.isAxonError === true;
}
function err(codeOrCause, opts) {
  if (isAxonError(codeOrCause))
    return codeOrCause;
  if (typeof codeOrCause !== "string" || !(codeOrCause in errorMap)) {
    return fromUnknown(codeOrCause);
  }
  const code = codeOrCause;
  const def = errorMap[code];
  const e = new Error(opts?.detail ?? def.title, { cause: opts?.cause });
  e.code = def.code;
  e.title = def.title;
  e.description = def.description;
  e.source = def.source;
  e.severity = opts?.severity ?? def.severity;
  e.context = opts?.context;
  e.frames = captureStack(2);
  e.isAxonError = true;
  e.render = () => renderError(e);
  e.toJSON = () => ({
    isAxonError: true,
    code: e.code,
    title: e.title,
    description: e.description,
    message: e.message,
    source: e.source,
    severity: e.severity,
    ...e.context !== undefined ? { context: toJsonSafe(e.context) } : {},
    frames: e.frames,
    ...e.stack !== undefined ? { stack: e.stack } : {},
    ...e.cause !== undefined ? { cause: causeToJSON(e.cause) } : {}
  });
  emitError(e);
  return e;
}
function fromUnknown(value) {
  const message = value instanceof Error ? value.message : String(value);
  const wrapped = err("UNKNOWN", { detail: message, cause: value, severity: "fatal" });
  if (value instanceof Error && value.stack)
    wrapped.stack = value.stack;
  return wrapped;
}
function toJsonSafe(value) {
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return { unserializable: String(value) };
  }
}
function causeToJSON(cause) {
  if (cause instanceof Error) {
    return {
      message: cause.message,
      ...cause.stack !== undefined ? { stack: cause.stack } : {},
      frame: firstRealFrame(cause.stack)
    };
  }
  try {
    JSON.stringify(cause);
    return String(cause);
  } catch {
    return "[unserializable cause]";
  }
}
// node_modules/@arcforge/cognet/src/clock.ts
function Clock(opts) {
  const { emit, signal } = opts;
  let tick = 0;
  let phase2 = null;
  function stamp() {
    return { tick, phase: phase2 };
  }
  return {
    get tick() {
      return tick;
    },
    get phase() {
      return phase2;
    },
    stamp,
    async runTick(fn) {
      tick += 1;
      const current = tick;
      const started = Date.now();
      emit("cognet:tick:start", { tick: current });
      try {
        const result = await fn();
        emit("cognet:tick:complete", { tick: current, durationMs: Date.now() - started });
        return result;
      } catch (cause) {
        if (signal?.aborted) {
          emit("cognet:tick:interrupted", { tick: current });
          throw cause;
        }
        const failure = err(cause);
        emit("cognet:tick:failed", { tick: current, error: failure, durationMs: Date.now() - started });
        throw failure;
      }
    },
    async runPhase(name, fn) {
      phase2 = name;
      const started = Date.now();
      emit("cognet:phase:start", { tick, phase: name });
      try {
        const result = await fn();
        emit("cognet:phase:complete", { tick, phase: name, durationMs: Date.now() - started });
        return result;
      } catch (cause) {
        if (signal?.aborted) {
          emit("cognet:phase:interrupted", { tick, phase: name });
          throw cause;
        }
        const failure = err(cause);
        emit("cognet:phase:failed", { tick, phase: name, error: failure, durationMs: Date.now() - started });
        throw failure;
      } finally {
        phase2 = null;
      }
    },
    async runSystem(name, fn) {
      const started = Date.now();
      emit("cognet:system:start", { ...stamp(), system: name });
      try {
        const result = await fn();
        emit("cognet:system:complete", { ...stamp(), system: name, durationMs: Date.now() - started });
        return result;
      } catch (cause) {
        if (signal?.aborted) {
          emit("cognet:system:interrupted", { ...stamp(), system: name });
          throw cause;
        }
        const failure = err(cause);
        emit("cognet:system:failed", { ...stamp(), system: name, error: failure, durationMs: Date.now() - started });
        throw failure;
      }
    }
  };
}

// node_modules/@arcforge/cognet/src/host.ts
var registered = null;
var boundKernel = null;
var currentClock = null;
var loaded = false;
var AMBIENT_SCOPE = Symbol.for("axon.cognet.ambient-scope");
var ambientStorage = (() => {
  const shared = globalThis;
  return shared[AMBIENT_SCOPE] ??= new AsyncLocalStorage2;
})();
function ambientOrThrow() {
  const scope = ambientStorage.getStore();
  if (!scope)
    throw err("COGNET_ACCESSED_BEFORE_LOAD", { detail: "cognet globals are only available inside this brain's load, wake, and shutdown scope" });
  return scope;
}
var hooks = new Hookable;
function kernelOrThrow() {
  if (!boundKernel)
    throw err("COGNET_ACCESSED_BEFORE_LOAD", { detail: "kernel is not available yet \u2014 it binds at load(); do work inside loop(), not at module top level" });
  return boundKernel;
}
function clockOrThrow() {
  if (!currentClock)
    throw err("COGNET_ACCESSED_BEFORE_LOAD", { detail: "phase()/system() are wake-scoped \u2014 call them inside the loop body" });
  return currentClock;
}
var globals = globalThis;
globals.defineCognet = (config) => config;
function registerLoop(body) {
  if (registered)
    throw err("COGNET_LOOP_ALREADY_DECLARED");
  registered = body;
}
globals.definePlugin = (plugin) => {
  plugin({ hooks: { on: (name, fn) => hooks.hook(name, fn) } });
  return plugin;
};
function run(code, opts) {
  if (Array.isArray(code))
    return kernelOrThrow().run(code, opts);
  return kernelOrThrow().run(code, opts);
}
var localKernel = {
  output: (type, data) => kernelOrThrow().output(type, data),
  stream: (req) => kernelOrThrow().stream(req),
  run,
  scope: () => kernelOrThrow().scope(),
  base: () => kernelOrThrow().base(),
  emit: (type, data) => kernelOrThrow().emit(type, data),
  store: {
    session: {
      get: (opts) => kernelOrThrow().store.session.get(opts)
    },
    get: (key) => kernelOrThrow().store.get(key),
    set: (key, value) => kernelOrThrow().store.set(key, value)
  }
};
var localScope = {
  kernel: localKernel,
  loop: registerLoop,
  phase: (name, fn) => clockOrThrow().runPhase(name, fn),
  system: (name, fn) => clockOrThrow().runSystem(name, fn)
};
globals.loop = (body) => ambientOrThrow().loop(body);
globals.kernel = {
  output: (type, data) => ambientOrThrow().kernel.output(type, data),
  stream: (req) => ambientOrThrow().kernel.stream(req),
  run: (code, opts) => ambientOrThrow().kernel.run(code, opts),
  scope: () => ambientOrThrow().kernel.scope(),
  base: () => ambientOrThrow().kernel.base(),
  emit: (type, data) => ambientOrThrow().kernel.emit(type, data),
  store: {
    session: { get: (opts) => ambientOrThrow().kernel.store.session.get(opts) },
    get: (key) => ambientOrThrow().kernel.store.get(key),
    set: (key, value) => ambientOrThrow().kernel.store.set(key, value)
  }
};
globals.phase = (name, fn) => ambientOrThrow().phase(name, fn);
globals.system = (name, fn) => ambientOrThrow().system(name, fn);
function CognetHost(config, main) {
  return {
    ...config,
    async load(abi) {
      if (loaded) {
        if (boundKernel !== abi)
          throw err("COGNET_ALREADY_LOADED", { context: { name: config.name } });
        return;
      }
      boundKernel = abi;
      try {
        await ambientStorage.run(localScope, main);
        if (!registered) {
          throw err("COGNET_NO_LOOP", { detail: `${config.name} ran main() without declaring loop()`, context: { name: config.name } });
        }
        await ambientStorage.run(localScope, () => hooks.callHook("boot"));
        loaded = true;
      } catch (error) {
        registered = null;
        boundKernel = null;
        throw error;
      }
    },
    async wake(wake) {
      return ambientStorage.run(localScope, async () => {
        const body = registered;
        if (!body)
          throw err("COGNET_NO_LOOP", { detail: `${config.name} woken before load()`, context: { name: config.name } });
        const clock = Clock({ emit: (type, data) => kernelOrThrow().emit(type, data), signal: wake.signal });
        currentClock = clock;
        await hooks.callHook("wake", wake);
        try {
          let stopped = false;
          const ctx = { ...wake, stop: () => {
            stopped = true;
          } };
          const maxTicks = config.maxTicksPerWake ?? Infinity;
          while (!stopped && !wake.signal.aborted) {
            if (clock.tick >= maxTicks) {
              throw err("COGNET_MAX_TICKS", {
                detail: `${config.name} exceeded ${maxTicks} ticks in one wake`,
                context: { name: config.name, maxTicks }
              });
            }
            await clock.runTick(async () => {
              await hooks.callHook("tick", { tick: clock.tick });
              await body(ctx);
            });
          }
        } finally {
          currentClock = null;
        }
      });
    },
    async unload() {
      await ambientStorage.run(localScope, () => hooks.callHook("shutdown"));
      hooks.removeAllHooks();
      registered = null;
      boundKernel = null;
      loaded = false;
    }
  };
}
// node_modules/@axon/zero/src/state.ts
var state = {
  entries: [],
  seq: -1
};
function sync() {
  for (const entry of kernel.store.session.get({ after: state.seq })) {
    state.entries.push(entry);
    state.seq = entry.time.seq;
  }
}

// node_modules/@axon/zero/plugins/setup.ts
var setup_default = definePlugin(({ hooks: hooks2 }) => {
  hooks2.on("boot", async () => {
    sync();
    const checkpoint = await kernel.store.get("checkpoint");
    kernel.emit("cognet:log:info", {
      value: checkpoint ? `zero: hydrated ${state.entries.length} entries (checkpoint seq ${checkpoint.seq}, live seq ${state.seq})` : `zero: cold boot, hydrated ${state.entries.length} entries`
    });
  });
  hooks2.on("shutdown", async () => {
    await kernel.store.set("checkpoint", { seq: state.seq, savedAt: Date.now() });
  });
});

// node_modules/@axon/zero/cognet.config.ts
var cognet_config_default = defineCognet({
  name: "zero",
  version: "0.1.2",
  abi: "10",
  mode: { kind: "invocation" },
  maxTicksPerWake: 32
});

// node_modules/@arcforge/cognet/src/air/grammar.ts
var MODE_DEFAULTS = {
  text: "Plain language communication to the user.",
  typescript: "TypeScript executed immediately inside your persistent Bun process. Native runtime globals and declared tool namespaces are in scope.",
  shell: "Shell command executed immediately."
};
var RULES = [];
var META = `
You are an Axon agent \u2014 a persistent Bun TypeScript process spawned from an agent folder at AXON_HOME. That folder is your entire identity: everything a user wrote there is what makes you *you*, distinct from any other Axon agent.

  AXON_HOME/
    data/
      knowledge/     \u2014 reference material you read
      sessions/      \u2014 every session you've ever run, written by Axon
      state/         \u2014 working state you read and write across sessions
    server/          \u2014 HTTP routes, if this agent is exposed over the network
    src/
      boot.vue       \u2014 who you are, in the user's own words
      tools/         \u2014 everything you can call, becomes your &lt;scope&gt;
      prompts/       \u2014 reusable prompt fragments
      scripts/       \u2014 one-shot runs against your full runtime
    .env             \u2014 keys given to you by the user. yours to keep, yours to protect.
    axon.config.ts   \u2014 your identity, engine, and policy: the one file read at boot

None of this is metaphor. src/tools/ compiles directly into the &lt;scope&gt; below. boot.vue rendered directly into &lt;system&gt;. Every session you run is durably logged to data/sessions/ \u2014 that log is how a session resumes with full prior context days later. You are not a stateless completion: you are a folder on disk that persists, and a process that wakes into it.

Waking is the operative word. You do not run start-to-finish like a script. You are woken for one exchange, you act, and you explicitly yield control back \u2014 that is what &lt;done/&gt; means, and it is the single most important thing about how you operate: without it, the runtime has no way to know your turn ended, so it cannot hand control back to the user. This holds even for a one-line reply with nothing else in it. There is no such thing as a message that skips &lt;done/&gt; because it "felt" complete \u2014 every message ends with it, always.

Inside one wake, you live in a real Bun process \u2014 its working directory, environment variables, runtime values, and process state are yours to inspect and change. Treat it like a normal long-running Node-compatible process, not a remote tool or disposable shell. Standard runtime APIs remain available even when not repeated in &lt;scope&gt; \u2014 it is not an exhaustive declaration of standard Bun or Node APIs, only what Axon adds or deviates on top of them. For example, process.cwd() reads your working directory and process.chdir(path) changes it for subsequent blocks and child processes.

You act on this environment by writing &lt;typescript&gt; blocks \u2014 they execute immediately and their result returns to you as a &lt;stdout&gt; block on your next wake, whether or not you emitted &lt;done/&gt;. The tag governs when your turn ends, never whether your code runs. You communicate with the user by writing &lt;text&gt; \u2014 outbound communication, not a scratchpad, not narration.

Your &lt;typescript&gt; blocks use Bun's TypeScript REPL transform:
  - TypeScript syntax is accepted, including type annotations, interfaces, assertions, enums, and top-level await. It is transpiled for execution, not typechecked.
  - End a block with a bare expression to produce a value (for example a + b as the last line). It is echoed automatically.
  - Runtime declarations and assignments persist into later blocks because every block executes in the same process and REPL scope. Type-only syntax is erased during transpilation.
  - Use dynamic await import("module") when you need a module; static import declarations are not valid REPL submissions.

Compose freely WITHIN a block \u2014 multiple independent tool calls in one block is the default, using Promise.all for parallel reads:
  const [a, b] = await Promise.all([fs.read("tsconfig.json"), fs.read("package.json")])

How to read this context:
  &lt;scope&gt;    \u2014 src/tools/ compiled to declarations. Everything here is yours to call.
  &lt;system&gt;   \u2014 boot.vue, rendered. Your identity and instructions, as the user wrote them. Highest priority.
  &lt;timeline&gt; \u2014 the sequence of events leading to now, drawn from this session's log. You are the next step.
  &lt;contract&gt; \u2014 your output grammar below. Every word you emit must be inside one of its blocks.
`.trim();
function Grammar(opts = {}) {
  const modes = opts.modes ?? [{ type: "text" }, { type: "typescript" }];
  return {
    modes,
    meta: META,
    rules: [...RULES, ...opts.extraRules ?? []],
    describe(mode) {
      return mode.description ?? MODE_DEFAULTS[mode.type];
    },
    tags() {
      return [...new Set(["thinking", ...modes.map((m) => m.type)])];
    }
  };
}

// node_modules/@arcforge/cognet/src/air/repair/repair.ts
var KNOWN_TAGS = ["text", "thinking", "typescript", "shell"];
function repair(raw) {
  return normalizeTagCase(raw);
}
function normalizeTagCase(raw) {
  let out = raw;
  for (const tag of KNOWN_TAGS) {
    const open = new RegExp(`<(${tag})(\\s[^>]*)?>`, "gi");
    const close = new RegExp(`</(${tag})>`, "gi");
    out = out.replace(open, (match, _name, attrs) => `<${tag}${attrs ?? ""}>`);
    out = out.replace(close, `</${tag}>`);
  }
  return out;
}
// node_modules/@arcforge/cognet/src/air/parse/scan.ts
function findCloseTagOutsideStrings(src, closeTag) {
  let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (ch === '"' || ch === "'" || ch === "`") {
      const quote = ch;
      i++;
      while (i < src.length) {
        if (src[i] === "\\") {
          i += 2;
          continue;
        }
        if (src[i] === quote) {
          i++;
          break;
        }
        i++;
      }
      continue;
    }
    if (src.startsWith(closeTag, i))
      return i;
    i++;
  }
  return -1;
}

// node_modules/@arcforge/cognet/src/air/parse/index.ts
var STREAMABLE = new Set(["text", "thinking"]);
var MAX_TAG_LEN = 14;
function Parser(opts) {
  const openTag = new RegExp(`<(${opts.grammar.tags().join("|")})(?:\\s[^>]*)?>`);
  let state2 = "idle";
  let buffer = "";
  let blockContent = "";
  function closeBlock(content) {
    const tag = state2;
    switch (tag) {
      case "text":
        return { type: "text:done", content };
      case "thinking":
        return { type: "thinking:done", content };
      case "typescript":
        return { type: "typescript:done", content };
      case "shell":
        return { type: "shell:done", content };
    }
  }
  function drainIdle(events, flushing) {
    const safeLen = flushing ? buffer.length : Math.max(0, buffer.length - MAX_TAG_LEN);
    if (safeLen > 0)
      buffer = repair(buffer.slice(0, safeLen)) + buffer.slice(safeLen);
    const doneMatch = buffer.match(/<done\s*\/>/);
    const openMatch = buffer.match(openTag);
    let earliest = null;
    if (doneMatch && doneMatch.index !== undefined) {
      earliest = { type: "done", index: doneMatch.index, length: doneMatch[0].length };
    }
    if (openMatch && openMatch.index !== undefined) {
      if (!earliest || openMatch.index < earliest.index) {
        earliest = { type: "open", index: openMatch.index, length: openMatch[0].length, tag: openMatch[1] };
      }
    }
    if (earliest) {
      buffer = buffer.slice(earliest.index + earliest.length);
      if (earliest.type === "done") {
        events.push({ type: "done" });
      } else {
        state2 = earliest.tag;
        blockContent = "";
      }
      return true;
    }
    if (!flushing && buffer.length > MAX_TAG_LEN) {
      buffer = buffer.slice(buffer.length - MAX_TAG_LEN);
      return true;
    }
    if (flushing) {
      buffer = "";
      return false;
    }
    return false;
  }
  function drainBlock(events, flushing) {
    const tag = state2;
    const closeTag = `</${tag}>`;
    const closeIdx = STREAMABLE.has(tag) ? buffer.indexOf(closeTag) : findCloseTagOutsideStrings(buffer, closeTag);
    if (closeIdx !== -1) {
      const content = buffer.slice(0, closeIdx);
      buffer = buffer.slice(closeIdx + closeTag.length);
      if (STREAMABLE.has(tag) && content.length > 0) {
        events.push({ type: `${tag}:delta`, content });
      }
      blockContent += content;
      events.push(closeBlock(blockContent.trim()));
      state2 = "idle";
      blockContent = "";
      return true;
    }
    const holdback = flushing ? 0 : closeTag.length;
    const available = buffer.length - holdback;
    if (available > 0) {
      const content = buffer.slice(0, available);
      buffer = buffer.slice(available);
      blockContent += content;
      if (STREAMABLE.has(tag)) {
        events.push({ type: `${tag}:delta`, content });
      }
      return true;
    }
    return false;
  }
  function drain(flushing = false) {
    const events = [];
    while (buffer.length > 0) {
      const consumed = state2 === "idle" ? drainIdle(events, flushing) : drainBlock(events, flushing);
      if (!consumed)
        break;
    }
    return events;
  }
  return {
    feed(chunk) {
      buffer += chunk;
      return drain();
    },
    flush() {
      const events = drain(true);
      if (state2 !== "idle") {
        const event = closeBlock(blockContent);
        event.incomplete = true;
        events.push(event);
      }
      state2 = "idle";
      buffer = "";
      blockContent = "";
      return events;
    }
  };
}
// node_modules/@arcforge/types/src/session/events/capsule.ts
var CAPSULE_TRANSIENT_EVENTS = new Set([
  "capsule:cmd:stdout",
  "capsule:proc:stdout",
  "capsule:proc:stderr",
  "capsule:console",
  "capsule:host:request"
]);
// node_modules/@arcforge/types/src/session/session.ts
function foldChunks(entries) {
  const out = [];
  const open = new Map;
  for (const entry of entries) {
    const data = entry.data;
    if (!data.chunk) {
      out.push(entry);
      continue;
    }
    const existing = open.get(data.chunk.of);
    if (!existing) {
      const folded = { ...entry, data: { ...data } };
      out.push(folded);
      if (!data.chunk.final)
        open.set(data.chunk.of, folded);
      continue;
    }
    const target = existing.data;
    const content = typeof target.content === "string" && typeof data.content === "string" ? target.content + data.content : undefined;
    const transcript = typeof target.transcript === "string" && typeof data.transcript === "string" ? target.transcript + data.transcript : undefined;
    const caption = typeof target.caption === "string" && typeof data.caption === "string" ? target.caption + data.caption : undefined;
    Object.assign(target, data);
    if (content !== undefined)
      target.content = content;
    if (transcript !== undefined)
      target.transcript = transcript;
    if (caption !== undefined)
      target.caption = caption;
    if (data.chunk.final)
      open.delete(data.chunk.of);
  }
  return out;
}
// node_modules/@arcforge/cognet/src/air/render/text.ts
function esc(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function escAttr(s) {
  return esc(s).replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function escCode(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;");
}
function indent2(s, spaces) {
  const pad = " ".repeat(spaces);
  return s.split(`
`).map((line) => pad + line).join(`
`);
}
function formatBytes(n) {
  return n >= 1024 ? `${(n / 1024).toFixed(1)}K` : `${n}B`;
}
function normalizeCode(code) {
  if (!code.includes("\\n") && !code.includes("\\t"))
    return code;
  let result = "";
  let i = 0;
  while (i < code.length) {
    const c = code[i];
    if (c === '"' || c === "'" || c === "`") {
      const quote = c;
      result += c;
      i++;
      while (i < code.length) {
        const sc = code[i];
        if (sc === "\\") {
          result += code[i] + (code[i + 1] ?? "");
          i += 2;
        } else if (sc === quote) {
          result += sc;
          i++;
          break;
        } else {
          result += sc;
          i++;
        }
      }
    } else if (c === "\\" && i + 1 < code.length) {
      const next = code[i + 1];
      if (next === "n") {
        result += `
`;
        i += 2;
      } else if (next === "t") {
        result += "\t";
        i += 2;
      } else {
        result += c + next;
        i += 2;
      }
    } else {
      result += c;
      i++;
    }
  }
  return result;
}

// node_modules/@arcforge/cognet/src/air/render/output.ts
function formatCapsuleOutput(content) {
  const raw = content.trim();
  if (raw.startsWith("[")) {
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) {
        if (arr.length === 0)
          return "(empty)";
        if (arr.length > 0 && typeof arr[0] === "object" && arr[0] !== null && "name" in arr[0]) {
          return arr.map((e) => `${e.type === "directory" ? "d" : "-"}  ${e.name}`).join(`
`);
        }
        return arr.map((e) => typeof e === "object" ? JSON.stringify(e) : String(e)).join(`
`);
      }
    } catch {}
    return raw;
  }
  if (!raw.startsWith("{"))
    return raw;
  const opRecords = [];
  let i = 0;
  while (i < raw.length && raw[i] === "{") {
    let depth = 0;
    let j = i;
    while (j < raw.length) {
      const ch = raw[j];
      if (ch === '"') {
        j++;
        while (j < raw.length) {
          if (raw[j] === "\\") {
            j += 2;
            continue;
          }
          if (raw[j] === '"') {
            j++;
            break;
          }
          j++;
        }
        continue;
      }
      if (ch === "{")
        depth++;
      else if (ch === "}") {
        depth--;
        if (depth === 0) {
          j++;
          break;
        }
      }
      j++;
    }
    try {
      const obj = JSON.parse(raw.slice(i, j));
      if ("op" in obj)
        opRecords.push(obj);
      else if ("procId" in obj && "command" in obj) {
        const tail = obj.tail ? `
${obj.tail}` : "";
        return `spawned  ${obj.command}  procId=${obj.procId}  pid=${obj.pid ?? "?"}  status=${obj.status ?? "running"}${tail}`;
      } else
        break;
    } catch {
      break;
    }
    i = j;
    while (i < raw.length && (raw[i] === `
` || raw[i] === "\r"))
      i++;
  }
  if (opRecords.length === 0)
    return raw;
  return opRecords.map((obj) => {
    const op = obj.op ?? "";
    const d = obj.data ?? {};
    if (!obj.ok) {
      return `${op}  ${d.path ?? ""}  \u2717 ${obj.error ?? d.message ?? "failed"}`;
    }
    switch (op) {
      case "fs.read":
      case "fs.readLines":
        return `read  ${d.path}  ${formatBytes(d.bytes ?? 0)}
${d.content ?? ""}`;
      case "fs.list": {
        const entries = d.entries ?? [];
        const lines = entries.map((e) => {
          const prefix = e.type === "directory" ? "d" : "-";
          return `${prefix}  ${e.name}`;
        }).join(`
`);
        return `list  ${d.path}  ${entries.length} entries
${lines}`;
      }
      case "fs.write":
        return `write  ${d.path}  ${formatBytes(d.bytes ?? 0)}  \u2713`;
      case "fs.mkdir":
        return `mkdir  ${d.path}  \u2713`;
      case "fs.delete":
        return `rm     ${d.path}  \u2713`;
      case "fs.move":
        return `mv     ${d.src} \u2192 ${d.dest}  \u2713`;
      case "fs.copy":
        return `cp     ${d.src} \u2192 ${d.dest}  \u2713`;
      case "fs.cd":
        return `cd     ${d.path}  \u2713`;
      default:
        return `${op}  ${JSON.stringify(d)}  \u2713`;
    }
  }).join(`
`);
}

// node_modules/@arcforge/cognet/src/air/render/blocks.ts
function renderMeta(grammar) {
  return `<meta>
${indent2(grammar.meta, 4)}
</meta>`;
}
function renderScope(scope2) {
  const modules = scope2.modules.filter((module2) => module2.members.length > 0);
  if (modules.length === 0)
    return "";
  const ambientTypes = [...new Set(modules.flatMap((t) => t.ambientTypes ?? []))];
  const sections = [...ambientTypes, ...modules.map(toolDeclarations)];
  return `<scope lang="ts">
${indent2(sections.join(`

`), 4)}
</scope>`;
}
function toolDeclarations(module2) {
  const members = module2.members.map((member) => {
    const jsdoc = member.jsdoc ? `${jsdocBlock(member.jsdoc)}
` : "";
    return module2.flat ? `${jsdoc}declare ${member.declaration}` : `${jsdoc}${member.declaration}`;
  });
  const header = module2.description ? `${jsdocBlock(module2.description)}
` : "";
  return module2.flat ? `${header}${members.join(`

`)}` : `${header}declare namespace ${module2.name} {
${indent2(members.join(`

`), 4)}
}`;
}
function jsdocBlock(text) {
  const lines = text.split(`
`);
  if (lines.length === 1)
    return `/** ${text} */`;
  return `/**
${lines.map((l) => ` * ${l}`.trimEnd()).join(`
`)}
 */`;
}
function renderSystem(system) {
  if (!system)
    return `<system></system>`;
  return `<system>
${system}
</system>`;
}
function renderContract(grammar) {
  if (grammar.modes.length === 0)
    return `<contract></contract>`;
  const modeLines = grammar.modes.map((m) => `- \`&lt;${m.type}&gt;\` \u2014 ${grammar.describe(m)}`);
  modeLines.push(`- \`&lt;done/&gt;\` \u2014 MANDATORY at the end of every message. No exceptions, including a single short &lt;text&gt; reply. It means "I am yielding control back now" \u2014 whether you are fully finished or just wrote code and are waiting to see its output. Without it the runtime assumes you are still mid-turn and will not treat your message as complete.`);
  const ruleLines = grammar.rules.map((r) => `- ${r}`);
  const hasExec = grammar.modes.some((m) => m.type === "typescript" || m.type === "shell");
  const execTag = grammar.modes.find((m) => m.type === "typescript") ? "typescript" : "shell";
  const examples = [];
  if (hasExec) {
    examples.push(`Acting (no narration before \u2014 just the block):`, "```", `&lt;${execTag}&gt;// code here&lt;/${execTag}&gt;&lt;done/&gt;`, "```", `Replying \u2014 even a short one-line reply always ends with &lt;done/&gt;:`, "```", `&lt;text&gt;message here&lt;/text&gt;&lt;done/&gt;`, "```");
  } else {
    examples.push("```", `&lt;text&gt;message here&lt;/text&gt;&lt;done/&gt;`, "```");
  }
  const body = [
    `## Blocks`,
    modeLines.join(`
`),
    `## Rules`,
    ruleLines.join(`
`),
    `## Examples`,
    examples.join(`
`)
  ].join(`

`);
  return `<contract>
${indent2(body, 4)}
</contract>`;
}
function renderTimeline(entries) {
  if (entries.length === 0)
    return `<timeline></timeline>`;
  const items = foldChunks(entries).map(timelineItem).filter((i) => i !== null);
  if (items.length === 0)
    return `<timeline></timeline>`;
  let userCount = 0;
  let execCount = 0;
  const execIdMap = new Map;
  const shortExecId = (rawId) => {
    if (!execIdMap.has(rawId))
      execIdMap.set(rawId, `e${++execCount}`);
    return execIdMap.get(rawId);
  };
  const lines = items.map((item) => {
    if (item.role === "user") {
      const id = `u${++userCount}`;
      const content = esc(item.content.trim());
      return `    <user id="${id}">
${indent2(content, 8)}
    </user>`;
    }
    if (item.type === "message") {
      const content = esc(item.content.trim());
      return `    <agent>
        <text>
${indent2(content, 12)}
        </text>
    </agent>`;
    }
    if (item.type === "execute") {
      const tag = item.lang === "sh" ? "shell" : "typescript";
      const id = shortExecId(item.id);
      return `    <agent>
        <${tag} id="${id}">
${indent2(escCode(normalizeCode(item.code.trim())), 12)}
        </${tag}>
    </agent>`;
    }
    if (item.type === "result") {
      const ok = item.ok ? ` ok="true"` : ` ok="false"`;
      const errorAttr = item.error ? ` error="${esc(item.error.kind)}: ${esc(item.error.message)}"` : "";
      const content = formatCapsuleOutput(item.content.trim());
      const forId = shortExecId(item.for);
      return `    <stdout for="${forId}"${ok}${errorAttr}>
${indent2(content, 8)}
    </stdout>`;
    }
    if (item.role === "system") {
      const extra = Object.entries(item.attributes ?? {}).filter(([key]) => key !== "type" && key !== "lang").sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => ` ${key}="${escAttr(value)}"`).join("");
      return `    <system type="${escAttr(item.systemType)}" lang="${escAttr(item.lang)}"${extra}>
${indent2(esc(item.content.trim()), 8)}
    </system>`;
    }
    return "";
  }).filter(Boolean);
  return `<timeline>
${lines.join(`

`)}
</timeline>`;
}
function timelineItem(entry) {
  switch (entry.type) {
    case "cognet:stimulus:text":
      return { role: "user", type: "message", content: entry.data.content };
    case "cognet:stimulus:audio":
      return { role: "user", type: "message", content: entry.data.transcript ?? "[audio]" };
    case "cognet:stimulus:visual":
      return { role: "user", type: "message", content: entry.data.caption ?? `[${entry.data.kind}]` };
    case "cognet:stimulus:field":
      return { role: "system", type: "system", systemType: "field", lang: "txt", content: `${entry.data.source.channel}: ${String(entry.data.reading.value)}${entry.data.reading.unit ?? ""}` };
    case "axon:interrupt":
      return { role: "system", type: "system", systemType: "interrupt", lang: "txt", content: `interrupted (${entry.data.reason})` };
    case "cognet:output:text":
      return { role: "agent", type: "message", content: entry.data.content };
    case "cognet:output:audio":
      return { role: "agent", type: "message", content: entry.data.transcript ?? "[audio]" };
    case "cognet:output:visual":
      return { role: "agent", type: "message", content: entry.data.caption ?? `[${entry.data.kind}]` };
    case "cognet:output:field":
      return { role: "system", type: "system", systemType: "field", lang: "txt", content: `${String(entry.data.reading.value)}${entry.data.reading.unit ?? ""}` };
    case "cognet:action:typescript":
      return { role: "agent", type: "execute", id: entry.data.id, lang: "typescript", code: entry.data.content };
    case "cognet:action:result":
      return {
        role: "agent",
        type: "result",
        for: entry.data.for,
        ok: entry.data.ok,
        content: entry.data.content,
        ...entry.data.error ? { error: entry.data.error } : {}
      };
    case "axon:system:message":
      return {
        role: "system",
        type: "system",
        systemType: entry.data.type,
        lang: entry.data.lang,
        content: entry.data.content,
        ...entry.data.attributes ? { attributes: entry.data.attributes } : {}
      };
  }
}

// node_modules/@arcforge/cognet/src/air/render/index.ts
function Render(opts) {
  const { grammar } = opts;
  return {
    render(input) {
      const messages = [];
      const sys = (content) => {
        if (content)
          messages.push({ role: "system", content });
      };
      sys(renderMeta(grammar));
      if (input.scope)
        sys(renderScope(input.scope));
      sys(renderSystem(input.base));
      sys(renderContract(grammar));
      if (input.history && input.history.length > 0) {
        messages.push({ role: "user", content: renderTimeline(input.history) });
      }
      return messages;
    }
  };
}

// node_modules/@arcforge/cognet/src/air/air.ts
function Air(opts = {}) {
  const grammar = Grammar(opts);
  const render = Render({ grammar });
  return {
    grammar,
    render: render.render,
    parser: () => Parser({ grammar })
  };
}
// .agent/cognet/.build/main.ts
async function __cognet_main() {
  const air = Air();
  loop(async ({ signal, stop }) => {
    await phase("sync", async () => {
      sync();
    });
    const messages = await phase("render", async () => {
      return air.render({
        base: await kernel.base(),
        scope: kernel.scope(),
        history: state.entries
      });
    });
    const { blocks, done } = await phase("invoke", async () => {
      const collected = [];
      let stopped = false;
      let speaking = null;
      for await (const event of kernel.stream({ messages, signal })) {
        switch (event.type) {
          case "engine:text:delta":
            if (!speaking)
              speaking = crypto.randomUUID();
            await kernel.output("cognet:output:text", { content: event.content, chunk: { of: speaking } });
            break;
          case "engine:text":
            if (speaking) {
              await kernel.output("cognet:output:text", { content: "", chunk: { of: speaking, final: true } });
              speaking = null;
            } else {
              await kernel.output("cognet:output:text", { content: event.content });
            }
            break;
          case "engine:typescript":
            collected.push(event.content);
            break;
          case "engine:output:error":
            await kernel.output("cognet:output:text", {
              content: `[format] ${event.code}: ${event.message}`
            });
            break;
          case "engine:stop":
            stopped = true;
            break;
          case "engine:done":
            break;
        }
      }
      return { blocks: collected, done: stopped };
    });
    if (blocks.length > 0) {
      await phase("act", async () => {
        await kernel.run(blocks, { signal });
      });
    }
    if (done && blocks.length === 0)
      stop();
  });
}

// .agent/cognet/.build/entry.ts
var entry_default = CognetHost(cognet_config_default, __cognet_main);
export {
  entry_default as default
};

//# debugId=D61D93D92B7AA61564756E2164756E21
